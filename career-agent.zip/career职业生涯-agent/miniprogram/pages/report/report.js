const { li } = require('../../utils/roles.js');

Page({
  data: {
    report: null,
    routes: [],
    sw: { s: [], w: [], o: [], t: [] },
    actions: [],
    disclaimer: '本报告由 AI 基于你提供的信息生成，仅供职业决策参考，不构成法律、心理或财务专业意见，也不承诺任何就业或薪酬结果。重大决定请结合现实并咨询专业人士。'
  },

  onLoad() {
    const r = getApp().globalData.report;
    if (!r) { wx.showToast({ title: '暂无报告', icon: 'none' }); return; }

    const rt = r.routes || {};
    const routes = [
      Object.assign({ key: 'stay', name: '🟢 留任发展' }, rt.stay || {}),
      Object.assign({ key: 'leave', name: '🟡 离职跳槽' }, rt.leave || {}),
      Object.assign({ key: 'transform', name: '🔵 转型 / 重启' }, rt.transform || {})
    ].filter(x => x.advice !== undefined);

    routes.forEach(x => {
      x.actions = (x.actions || []).map(li);
      x.color = x.probability >= 60 ? '#5bff9e' : x.probability >= 40 ? '#e9c46a' : '#ff7676';
      x.barW = Math.max(4, Math.min(100, +x.probability || 0));
    });

    this.setData({
      report: r,
      routes,
      sw: {
        s: (r.sw.strength || []).map(li),
        w: (r.sw.weakness || []).map(li),
        o: (r.sw.opportunity || []).map(li),
        t: (r.sw.threat || []).map(li)
      },
      actions: (r.actions || []).map(li)
    });
  },

  toCard() { wx.navigateTo({ url: '/pages/card/card' }); },
  restart() {
    getApp().globalData.report = null;
    wx.navigateBack({ delta: 2 });
  }
});
