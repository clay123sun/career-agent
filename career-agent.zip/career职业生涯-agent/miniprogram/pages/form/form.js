const { ROLES, EDUCATIONS, INDUSTRIES, PERSONALITY, buildUserPrompt, normalizeReport } = require('../../utils/roles.js');
const { request } = require('../../utils/api.js');

Page({
  data: {
    roleId: '',
    roleName: '',
    roleTagline: '',
    educations: EDUCATIONS,
    industries: INDUSTRIES,
    personality: PERSONALITY.map(t => ({ label: t, on: false })),
    years: 8,
    eduIndex: 0,
    indIndex: 0,
    position: '',
    personalityExtra: '',
    achievements: '',
    projects: '',
    rewards: '',
    gains: '',
    relations: '',
    company: '',
    other: ''
  },

  onLoad(q) {
    const r = ROLES[q.role] || {};
    this.setData({ roleId: q.role, roleName: r.name, roleTagline: r.tagline });
  },

  onYears(e) { this.setData({ years: e.detail.value }); },
  onEdu(e) { this.setData({ eduIndex: +e.detail.value }); },
  onInd(e) { this.setData({ indIndex: +e.detail.value }); },
  onInput(e) { this.setData({ [e.currentTarget.dataset.field]: e.detail.value }); },

  toggleTag(e) {
    const i = e.currentTarget.dataset.i;
    const key = `personality[${i}].on`;
    this.setData({ [key]: !this.data.personality[i].on });
  },

  selTags() { return this.data.personality.filter(t => t.on).map(t => t.label); },

  async submit() {
    const d = this.data;
    const miss = [];
    if (!d.position.trim()) miss.push('当前岗位');
    if (!INDUSTRIES[d.indIndex]) miss.push('所在行业');
    if (!EDUCATIONS[d.eduIndex]) miss.push('学历背景');
    if (!d.achievements.trim()) miss.push('业绩成果');
    if (!this.selTags().length) miss.push('性格特点');
    if (miss.length) { wx.showToast({ title: '请填写：' + miss.join('、'), icon: 'none' }); return; }

    // 仅采集“处境”诊断输入；名片信息（公司/职务/电话/微信/照片/二维码）在生成分身卡时填写
    const payload = {
      role: d.roleId,
      years: +d.years,
      education: EDUCATIONS[d.eduIndex],
      industry: INDUSTRIES[d.indIndex],
      position: d.position.trim(),
      personality: this.selTags().join('、'),
      achievements: d.achievements.trim(),
      projects: d.projects.trim(),
      rewards: d.rewards.trim(),
      gains: d.gains.trim(),
      relations: d.relations.trim(),
      company: d.company.trim(),
      other: d.other.trim()
    };

    wx.showLoading({ title: '星策诊断中…', mask: true });
    try {
      const r = ROLES[d.roleId];
      const cfg = getApp().globalData.modelCfg || { mode: 'local' };
      const res = await request('/api/analyze', {
        systemPrompt: r.systemPrompt,
        userPrompt: buildUserPrompt(payload),
        config: cfg
      });
      let obj = null;
      if (res && res.content) {
        const m = res.content.match(/\{[\s\S]*\}/);
        if (m) { try { obj = JSON.parse(m[0]); } catch (e) { obj = null; } }
      }
      if (!obj) throw new Error((res && res.error) || '模型未返回结构化报告');

      const g = getApp().globalData;
      g.role = d.roleId;
      g.payload = payload;
      g.report = normalizeReport(obj, d.roleId);
      wx.hideLoading();
      wx.navigateTo({ url: '/pages/report/report' });
    } catch (e) {
      wx.hideLoading();
      wx.showModal({ title: '诊断失败', content: e.message, showCancel: false });
    }
  }
});
