const { request } = require('../../utils/api.js');

Page({
  data: {
    loading: false,
    error: '',
    ready: false,
    bgPath: '',
    payload: null,
    companyName: '',
    duty: '',
    identity: '',
    phone: '',
    wechat: '',
    photoPath: '',
    qrPath: ''
  },

  onLoad() {
    const g = getApp().globalData;
    this.g = g;
    // 现任职务默认带出诊断岗位，生成卡片时可改
    this.setData({ payload: g.payload, duty: (g.payload && g.payload.position) || '' });
  },

  onInput(e) { this.setData({ [e.currentTarget.dataset.field]: e.detail.value }); },

  choosePhoto() {
    wx.chooseMedia({ count: 1, mediaType: ['image'], sourceType: ['album', 'camera'], success: r => this.setData({ photoPath: r.tempFiles[0].tempFilePath }) });
  },
  chooseQr() {
    wx.chooseMedia({ count: 1, mediaType: ['image'], sourceType: ['album', 'camera'], success: r => this.setData({ qrPath: r.tempFiles[0].tempFilePath }) });
  },
  rmPhoto() { this.setData({ photoPath: '' }); },
  rmQr() { this.setData({ qrPath: '' }); },

  async genBg() {
    const p = this.data.payload;
    if (!p) { this.setData({ error: '缺少用户信息，请先完成诊断' }); return; }
    this.setData({ loading: true, error: '', ready: false });
    try {
      let bgPath = '';
      if (this.data.photoPath) {
        // 关键：用上传照片（保留本人），AI 仅替换背景
        const b64 = await this.fileB64(this.data.photoPath);
        const editPrompt =
          '保持照片中人物完全不变（面部、发型、服装、姿态、表情原样保留），仅把背景替换为高端未来科幻科技风场景：' +
          '深蓝紫渐变星空、金色光环与上升光柱、抽象职场星图与数据流，电影感打光，画面干净高级，人物与背景自然融合，9:16 竖版';
        const res = await request('/api/edit-image', { image: b64, prompt: editPrompt, size: '1024x1536' });
        if (!res || !res.b64_json) {
          throw new Error((res && res.error) || '换背景失败（请确认服务已启动且可访问外网）');
        }
        bgPath = await this.b64File(res.b64_json, 'xc_bg.png');
      }
      // 无照片时不调 AI 生成人物（避免冒出陌生人），用渐变背景
      this.setData({ bgPath, loading: false, ready: true }, () => this.renderCanvas());
    } catch (e) {
      this.setData({ loading: false, error: e.message });
    }
  },

  fileB64(path) {
    return new Promise((resolve, reject) => {
      wx.getFileSystemManager().readFile({ filePath: path, encoding: 'base64', success: r => resolve(r.data), fail: reject });
    });
  },

  b64File(b64, name) {
    return new Promise((resolve, reject) => {
      const fs = wx.getFileSystemManager();
      const path = `${wx.env.USER_DATA_PATH}/${name}`;
      fs.writeFile({
        filePath: path,
        data: wx.base64ToArrayBuffer(b64),
        encoding: 'binary',
        success: () => resolve(path),
        fail: reject
      });
    });
  },

  getNode() {
    return new Promise((resolve) => {
      wx.createSelectorQuery().in(this).select('#cardCanvas').fields({ node: true, size: true })
        .exec(res => resolve(res && res[0] ? res[0].node : null));
    });
  },

  async renderCanvas() {
    const canvas = await this.getNode();
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = 750, H = 1334;
    canvas.width = W; canvas.height = H;
    ctx.clearRect(0, 0, W, H);

    const draw = (src) => new Promise((rs) => {
      if (!src) return rs(null);
      const im = canvas.createImage();
      im.src = src;
      im.onload = () => rs(im);
      im.onerror = () => rs(null);
    });
    const cover = (im) => {
      if (!im) return;
      const s = Math.max(W / im.width, H / im.height);
      const w = im.width * s, h = im.height * s;
      ctx.drawImage(im, (W - w) / 2, (H - h) / 2, w, h);
    };

    const bg = await draw(this.data.bgPath);
    if (bg) { cover(bg); }
    else {
      // 渐变背景（无照片时，不出现陌生人）
      const g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#1a1140'); g.addColorStop(0.5, '#241a5e'); g.addColorStop(1, '#0e0a24');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      const rg = ctx.createRadialGradient(375, 360, 40, 375, 360, 320);
      rg.addColorStop(0, 'rgba(108,92,240,.35)'); rg.addColorStop(1, 'rgba(108,92,240,0)');
      ctx.fillStyle = rg; ctx.fillRect(0, 0, W, H);
    }
    // 顶部 / 底部渐变带，保证文字可读
    let tg = ctx.createLinearGradient(0, 0, 0, 260);
    tg.addColorStop(0, 'rgba(8,10,26,.78)'); tg.addColorStop(1, 'rgba(8,10,26,0)');
    ctx.fillStyle = tg; ctx.fillRect(0, 0, W, 260);
    let bg2 = ctx.createLinearGradient(0, H, 0, H - 300);
    bg2.addColorStop(0, 'rgba(8,10,26,.82)'); bg2.addColorStop(1, 'rgba(8,10,26,0)');
    ctx.fillStyle = bg2; ctx.fillRect(0, H - 300, W, 300);

    // 名片信息来自本页表单（生成卡片时填写）；背景图已含本人形象，不再叠圆形头像
    const p = this.data;
    ctx.textAlign = 'center';
    if (p.companyName) { ctx.fillStyle = '#fff'; ctx.font = 'bold 40px sans-serif'; ctx.fillText(p.companyName, 375, 86); }
    ctx.fillStyle = '#e9c46a'; ctx.font = '600 32px sans-serif';
    ctx.fillText(p.duty || (this.g.payload && this.g.payload.position) || '', 375, 134);
    if (p.identity) { ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.font = '24px sans-serif'; ctx.fillText('｜ ' + p.identity, 375, 176); }

    ctx.textAlign = 'left'; ctx.fillStyle = '#fff'; ctx.font = '28px sans-serif';
    let y = H - 150;
    if (p.phone) { ctx.fillText('📞 ' + p.phone, 60, y); y += 46; }
    if (p.wechat) { ctx.fillText('💬 微信 ' + p.wechat, 60, y); y += 46; }

    const qr = await draw(p.qrPath);
    if (qr) {
      ctx.fillStyle = '#fff'; ctx.fillRect(W - 210, y - 30, 150, 150);
      ctx.drawImage(qr, W - 202, y - 22, 134, 134);
      ctx.fillStyle = '#aab2d8'; ctx.font = '20px sans-serif'; ctx.textAlign = 'center';
      ctx.fillText('扫码关注', W - 135, y + 132); ctx.textAlign = 'left';
    }

    ctx.textAlign = 'center'; ctx.fillStyle = '#e9c46a'; ctx.font = 'bold 30px sans-serif';
    ctx.fillText('🌟 星策 · 未来职场就业神器', 375, H - 66);
    ctx.fillStyle = 'rgba(255,255,255,.22)'; ctx.font = '600 30px sans-serif';
    ctx.fillText('免费体验版', 375, H - 26);
  },

  async save() {
    const canvas = await this.getNode();
    if (!canvas) { wx.showToast({ title: '画布未就绪', icon: 'none' }); return; }
    wx.showLoading({ title: '导出中…', mask: true });
    wx.canvasToTempFilePath({
      canvas,
      success: r => {
        wx.saveImageToPhotosAlbum({
          filePath: r.tempFilePath,
          success: () => { wx.hideLoading(); wx.showToast({ title: '已保存到相册' }); },
          fail: err => {
            wx.hideLoading();
            wx.showModal({ title: '保存失败', content: (err.errMsg || '') + '（请在设置中允许保存到相册）', showCancel: false });
          }
        });
      },
      fail: () => { wx.hideLoading(); wx.showToast({ title: '导出失败', icon: 'none' }); }
    });
  }
});
