const ROLES = [
  { id: 'novice', name: '职场小白', icon: '🌱', tagline: '0-3年 · 找到你的赛道' },
  { id: 'midlife', name: '中年危机', icon: '🌪️', tagline: '35-50岁 · 守住与突围' },
  { id: 'unemployed', name: '失业求职', icon: '🔍', tagline: '待业/裸辞 · 重启节奏' },
  { id: 'restart', name: '职场二春', icon: '🌸', tagline: '重返职场 · 重启破局' },
  { id: 'future', name: '未来就业', icon: '🚀', tagline: '在校/前瞻 · 赢在AI时代' }
];
Page({
  data: { roles: ROLES },
  select(e) {
    const id = e.currentTarget.dataset.id;
    getApp().globalData.role = id;
    wx.navigateTo({ url: '/pages/form/form?role=' + id });
  }
});
