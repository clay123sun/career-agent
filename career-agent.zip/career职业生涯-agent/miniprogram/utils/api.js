const app = getApp();
function request(path, data) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: app.globalData.baseURL + path,
      method: 'POST',
      data: data,
      header: { 'Content-Type': 'application/json' },
      success: r => resolve(r.data),
      fail: e => reject(e)
    });
  });
}
module.exports = { request };
