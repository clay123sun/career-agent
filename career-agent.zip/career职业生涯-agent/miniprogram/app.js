App({
  globalData: {
    // 部署后改成你的 https 公网域名（需 ICP 备案 + 微信小程序 request 合法域名）
    baseURL: 'https://你的服务器域名',
    // 小程序无内置"模拟引擎"，必须走真实大模型。
    // 默认调本地 Ollama（与 server.js 同机）；生产建议改为云端：
    //   { mode:'cloud', base:'https://api.deepseek.com/v1', key:'sk-...', model:'deepseek-chat' }
    modelCfg: { mode: 'local', ollama: 'http://localhost:11434', model: 'qwen2.5:7b' },
    role: null,
    payload: null,
    report: null
  }
})
