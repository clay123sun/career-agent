/* =====================================================================
 * 星策 · 未来职场就业神器 —— 本地服务端（零依赖，Node 内置模块）
 * 功能：
 *   1) 静态托管 index.html / prompts.js / assets
 *   2) POST /api/generate-image —— 代理 hongqiye gpt-image-2 生成职业形象
 *   3) POST /api/analyze        —— 代理真实大模型（云端 OpenAI 兼容 / 本地 Ollama）
 *   4) POST /api/create-order   —— 创建订单（当前为演示 mock，预留微信支付 JSAPI）
 *
 * 运行： node server.js   （默认端口 8787，可用 PORT 环境变量覆盖）
 * 生产提示：敏感 key 建议改用环境变量，勿硬编码进仓库。
 * ===================================================================== */
const http = require("http");
const fs = require("fs");
const path = require("path");
const https = require("https");

const ROOT = __dirname;
const PORT = process.env.PORT || 8787;

// —— hongqiye gpt-image-2 配置（仅服务端使用）——
const HQ_API_KEY = process.env.HQ_API_KEY || "sk-xLLHxUs2dnzbQaToZIA2E85YzkLUCB11UjZAB4jFqhOIgIDk";
const HQ_ENDPOINT = "https://cloud.hongqiye.com/v1/images/generations";
const HQ_MODEL = "gpt-image-2";

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".json": "application/json; charset=utf-8",
};

function setCORS(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type,Authorization");
}
function sendFile(res, file) {
  setCORS(res);
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404); res.end("404 Not Found"); return; }
    res.writeHead(200, {
      "Content-Type": MIME[path.extname(file)] || "application/octet-stream",
      "Cache-Control": "no-store, no-cache, must-revalidate"
    });
    res.end(buf);
  });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (c) => (data += c));
    req.on("end", () => { try { resolve(data ? JSON.parse(data) : {}); } catch (e) { reject(e); } });
    req.on("error", reject);
  });
}

/* ---------- 临时错误重试（应对 hongqiye 偶发限流/拒绝）----------
 * task() 返回 {b64_json} 或 {error}。命中 b64_json 立即成功；
 * 命中"看起来是临时"的错误（限流/拒绝/超时/网络）则退避重试，最多 attempts 次；
 * 命中明确错误（如 key 无效）则直接返回，不浪费时间。 */
function withRetry(task, attempts, baseDelay) {
  return new Promise(async (resolve) => {
    let last = "空响应";
    for (let i = 0; i < attempts; i++) {
      const r = await task();
      if (r.b64_json) return resolve(r);
      last = r.error || "空响应";
      const transient = /invalid_request|rejected|rate|429|超时|网络|timeout|network|busy/i.test(last);
      if (!transient || i >= attempts - 1) return resolve({ error: last });
      await new Promise((s) => setTimeout(s, baseDelay * (i + 1)));
    }
    resolve({ error: last });
  });
}

/* ---------- 生图：hongqiye gpt-image-2 ---------- */
function callHongqiye(prompt, size) {
  return new Promise((resolve) => {
    const body = JSON.stringify({ model: HQ_MODEL, prompt: prompt, n: 1, size: size || "1024x1536" });
    const url = new URL(HQ_ENDPOINT);
    const req = https.request(
      { hostname: url.hostname, path: url.pathname, method: "POST", timeout: 300000,
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + HQ_API_KEY, "Content-Length": Buffer.byteLength(body) } },
      (resp) => {
        let chunks = "";
        resp.on("data", (d) => (chunks += d));
        resp.on("end", () => {
          try {
            const json = JSON.parse(chunks);
            const b64 = json.b64_json || (json.data && json.data[0] && json.data[0].b64_json);
            if (b64) resolve({ b64_json: b64 });
            else if (json.error) resolve({ error: typeof json.error === "string" ? json.error : JSON.stringify(json.error) });
            else resolve({ error: "未返回 b64_json：" + chunks.slice(0, 200) });
          } catch (e) { resolve({ error: "响应解析失败：" + chunks.slice(0, 200) }); }
        });
      }
    );
    req.on("timeout", () => { req.destroy(); resolve({ error: "生图请求超时（>300s）" }); });
    req.on("error", (e) => resolve({ error: "生图网络错误：" + e.message }));
    req.write(body); req.end();
  });
}

/* ---------- 换背景：gpt-image-2 图生图（/v1/images/edits，multipart）----------
 * 实测 2026-10-07：multipart 上传人物照片 + prompt，47s 返回 1024x1536，
 * 人物面部/服装保留，背景替换为科技风场景。 */
function callHongqiyeEdit(imageBase64, prompt, size) {
  return new Promise((resolve) => {
    const boundary = "----xc" + Date.now().toString(36);
    const pre = Buffer.from(
      `--${boundary}\r\nContent-Disposition: form-data; name="model"\r\n\r\ngpt-image-2\r\n` +
      `--${boundary}\r\nContent-Disposition: form-data; name="prompt"\r\n\r\n${prompt}\r\n` +
      `--${boundary}\r\nContent-Disposition: form-data; name="size"\r\n\r\n${size || "1024x1536"}\r\n` +
      `--${boundary}\r\nContent-Disposition: form-data; name="image"; filename="person.png"\r\nContent-Type: image/png\r\n\r\n`,
      "utf8");
    const post = Buffer.from(`\r\n--${boundary}--\r\n`, "utf8");
    const imgBuf = Buffer.from(imageBase64, "base64");
    const body = Buffer.concat([pre, imgBuf, post]);
    const req = https.request(
      { hostname: "cloud.hongqiye.com", path: "/v1/images/edits", method: "POST", timeout: 300000,
        headers: { "Content-Type": "multipart/form-data; boundary=" + boundary,
                   Authorization: "Bearer " + HQ_API_KEY, "Content-Length": body.length } },
      (resp) => {
        const chunks = [];
        resp.on("data", (d) => chunks.push(d));
        resp.on("end", () => {
          const txt = Buffer.concat(chunks).toString("utf8");
          try {
            const json = JSON.parse(txt);
            const b64 = json.b64_json || (json.data && json.data[0] && json.data[0].b64_json);
            if (b64) resolve({ b64_json: b64 });
            else if (json.error) resolve({ error: typeof json.error === "string" ? json.error : JSON.stringify(json.error) });
            else resolve({ error: "编辑接口未返回 b64_json：" + txt.slice(0, 200) });
          } catch (e) { resolve({ error: "编辑接口响应解析失败：" + txt.slice(0, 200) }); }
        });
      }
    );
    req.on("timeout", () => { req.destroy(); resolve({ error: "换背景请求超时（>300s）" }); });
    req.on("error", (e) => resolve({ error: "换背景网络错误：" + e.message }));
    req.write(body); req.end();
  });
}

/* ---------- 真实大模型代理 ---------- */
// 云端：OpenAI 兼容协议（DeepSeek / OpenAI / 通义 / 硅基流动 等）
function callCloudLLM(systemPrompt, userPrompt, cfg) {
  return new Promise((resolve) => {
    const base = (cfg.base || "https://api.openai.com/v1").replace(/\/$/, "");
    const body = JSON.stringify({
      model: cfg.model || "deepseek-chat",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      temperature: 0.35, stream: false,
    });
    const u = new URL(base + "/chat/completions");
    const req = https.request(
      { hostname: u.hostname, path: u.pathname, method: "POST", timeout: 120000,
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + cfg.key, "Content-Length": Buffer.byteLength(body) } },
      (resp) => {
        let c = ""; resp.on("data", (d) => (c += d));
        resp.on("end", () => {
          try {
            const j = JSON.parse(c);
            const content = j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
            if (content) resolve({ content }); else resolve({ error: "云端模型未返回内容：" + c.slice(0, 200) });
          } catch (e) { resolve({ error: "云端模型响应解析失败（检查 key/endpoint）" }); }
        });
      }
    );
    req.on("timeout", () => { req.destroy(); resolve({ error: "云端模型请求超时（>120s）" }); });
    req.on("error", (e) => resolve({ error: "云端模型网络错误：" + e.message }));
    req.write(body); req.end();
  });
}
// 本地：Ollama（http://localhost:11434）
function callOllamaLLM(systemPrompt, userPrompt, cfg) {
  return new Promise((resolve) => {
    const base = (cfg.ollama || "http://localhost:11434").replace(/\/$/, "");
    const body = JSON.stringify({
      model: cfg.model || "qwen2.5:7b",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      stream: false,
    });
    const u = new URL(base + "/api/chat");
    const req = http.request(
      { hostname: u.hostname, port: u.port || 80, path: u.pathname, method: "POST", timeout: 180000,
        headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) } },
      (resp) => {
        let c = ""; resp.on("data", (d) => (c += d));
        resp.on("end", () => {
          try {
            const j = JSON.parse(c);
            const content = j.message && j.message.content;
            if (content) resolve({ content }); else resolve({ error: "本地模型未返回内容（Ollama 已启动？）" });
          } catch (e) { resolve({ error: "本地模型响应解析失败" }); }
        });
      }
    );
    req.on("timeout", () => { req.destroy(); resolve({ error: "本地模型请求超时（Ollama 未启动？）" }); });
    req.on("error", (e) => resolve({ error: "本地模型网络错误：" + e.message + "（确认 Ollama 在运行）" }));
    req.write(body); req.end();
  });
}

const server = http.createServer(async (req, res) => {
  setCORS(res);
  if (req.method === "OPTIONS") { res.writeHead(204); res.end(); return; }
  const url = req.url.split("?")[0];

  // —— API ——
  if (req.method === "POST" && url === "/api/generate-image") {
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    try {
      const p = await readBody(req);
      if (!p.prompt) { res.end(JSON.stringify({ error: "缺少 prompt" })); return; }
      const r = await withRetry(() => callHongqiye(p.prompt, p.size), 3, 1500);
      res.end(JSON.stringify(r));
    } catch (e) { res.end(JSON.stringify({ error: e.message })); }
    return;
  }

  if (req.method === "POST" && url === "/api/edit-image") {
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    try {
      const p = await readBody(req);
      if (!p.image) { res.end(JSON.stringify({ error: "缺少 image(base64)" })); return; }
      const r = await withRetry(() => callHongqiyeEdit(p.image, p.prompt || "替换背景为高端未来科技风场景，保留人物原样", p.size), 3, 2000);
      res.end(JSON.stringify(r));
    } catch (e) { res.end(JSON.stringify({ error: e.message })); }
    return;
  }

  if (req.method === "POST" && url === "/api/analyze") {
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    try {
      const p = await readBody(req);
      const cfg = p.config || {};
      let result;
      if (cfg.mode === "cloud") result = await callCloudLLM(p.systemPrompt, p.userPrompt, cfg);
      else if (cfg.mode === "local") result = await callOllamaLLM(p.systemPrompt, p.userPrompt, cfg);
      else result = { error: "未知模型模式" };
      res.end(JSON.stringify(result));
    } catch (e) { res.end(JSON.stringify({ error: e.message })); }
    return;
  }

  if (req.method === "POST" && url === "/api/create-order") {
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    /* 真实微信支付接入点（JSAPI）：
       1) 在微信商户平台配置 APIv3 密钥与证书
       2) 用商户号 mchid + 证书调用 https://api.mch.weixin.qq.com/v3/pay/transactions/jsapi
       3) 返回 prepay_id，前端 wx.requestPayment 拉起支付
       此处为演示，返回 mock 订单。 */
    const orderId = "XC" + Date.now();
    res.end(JSON.stringify({ mock: true, orderId, prepayInfo: null, msg: "演示订单，真实支付请接入微信支付 JSAPI" }));
    return;
  }

  // —— 静态文件 ——
  let file = url === "/" ? "/index.html" : url;
  const safe = path.normalize(file).replace(/^(\.\.[/\\])+/, "");
  const full = path.join(ROOT, safe);
  if (!full.startsWith(ROOT)) { res.writeHead(403); res.end("forbidden"); return; }
  sendFile(res, full);
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`🌟 星策 · 未来职场就业神器 已启动： http://127.0.0.1:${PORT}`);
});
