/* =====================================================================
 * pdf.js —— 零依赖中文 PDF 生成器 v2（真字体嵌入版）
 * 方案：嵌入 Droid Sans Fallback（Apache 2.0，assets/fonts/），
 *       CIDFontType2 + Identity-H + CIDToGIDMap /Identity，
 *       文本按 字形GID 双字节编码写入；/W 数组按 1000/em 换算，
 *       FontFile2 用 zlib deflate 压缩。
 * 实测：Chrome pdfium / MuPDF 均可渲染（非嵌入 STSong-Light 两家都不渲染，已弃用）。
 * ===================================================================== */
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const A4 = { w: 595.28, h: 841.89 };
const MARGIN = 52;
const FONT_PATH = path.join(__dirname, "assets", "fonts", "DroidSansFallback.ttf");

/* ---------------- TTF 解析（cmap/head/hhea/hmtx）---------------- */
function loadFont(file) {
  const b = fs.readFileSync(file);
  const u16 = (o) => b.readUInt16BE(o);
  const i16 = (o) => b.readInt16BE(o);
  const u32 = (o) => b.readUInt32BE(o);
  const numTables = u16(4);
  const tables = {};
  for (let i = 0; i < numTables; i++) {
    const off = 12 + i * 16;
    tables[b.toString("ascii", off, off + 4)] = { off: u32(off + 8), len: u32(off + 12) };
  }
  if (!tables.cmap || !tables.head || !tables.hhea || !tables.hmtx) throw new Error("字体缺少必要表");
  // unitsPerEm: head 表 offset 18
  const unitsPerEm = u16(tables.head.off + 18);
  // numberOfHMetrics: hhea offset 34
  const numHMetrics = u16(tables.hhea.off + 34);
  // cmap: 找最佳子表 (3,10)>(0,6)>(3,1)>(0,4)>(0,3)
  const cm = tables.cmap.off;
  const nEnc = u16(cm + 2);
  let best = null, bestScore = -1;
  for (let i = 0; i < nEnc; i++) {
    const rec = cm + 4 + i * 8;
    const pid = u16(rec), eid = u16(rec + 2), off = cm + u32(rec + 4);
    let score = -1;
    if (pid === 3 && eid === 10) score = 5;
    else if (pid === 0 && eid === 6) score = 4;
    else if (pid === 3 && eid === 1) score = 3;
    else if (pid === 0 && (eid === 4 || eid === 3)) score = 2;
    if (score > bestScore) { bestScore = score; best = off; }
  }
  if (!best) throw new Error("字体 cmap 无可用子表");
  // 解析子表
  const fmt = u16(best);
  const map = new Map(); // code -> gid
  if (fmt === 4) {
    const segX2 = u16(best + 6);
    const seg = segX2 / 2;
    const endO = best + 14, startO = endO + segX2 + 2, deltaO = startO + segX2, rangeO = deltaO + segX2;
    for (let s = 0; s < seg; s++) {
      const end = u16(endO + s * 2), start = u16(startO + s * 2);
      const delta = i16(deltaO + s * 2), ro = u16(rangeO + s * 2);
      if (start === 0xffff) continue;
      for (let c = start; c <= end; c++) {
        let g;
        if (ro === 0) g = (c + delta) & 0xffff;
        else {
          const gi = rangeO + s * 2 + ro + (c - start) * 2;
          g = u16(gi);
          if (g) g = (g + delta) & 0xffff;
        }
        if (g) map.set(c, g);
      }
    }
  } else if (fmt === 12) {
    const nGroups = u32(best + 12);
    for (let i = 0; i < nGroups; i++) {
      const g = best + 16 + i * 12;
      const s = u32(g), e = u32(g + 4), sg = u32(g + 8);
      for (let c = s; c <= e; c++) map.set(c, sg + (c - s));
    }
  } else throw new Error("暂不支持 cmap format " + fmt);
  // hmtx 宽度
  const widthOf = (gid) => {
    const idx = Math.min(gid, numHMetrics - 1);
    return u16(tables.hmtx.off + idx * 4);
  };
  return { map, unitsPerEm, widthOf, raw: b, numGlyphs: map.size };
}

const FONT = (() => { try { return loadFont(FONT_PATH); } catch (e) { console.error("PDF 字体加载失败：", e.message); return null; } })();
const toW1000 = (aw) => Math.round(aw * 1000 / (FONT ? FONT.unitsPerEm : 1000));

/* ---------------- 文本 -> GID ---------------- */
function gidsOf(s) {
  const out = [];
  for (const ch of String(s)) {
    let g = FONT && FONT.map.get(ch.codePointAt(0));
    out.push(g || 0);
  }
  return out;
}
function hexGids(s) {
  return gidsOf(s).map((g) => g.toString(16).padStart(4, "0")).join("").toUpperCase();
}
/* 精确文本宽度（1000 单位空间 * size） */
function textWidth(s, size) {
  if (!FONT) return String(s).length * size;
  let w = 0;
  for (const g of gidsOf(s)) w += toW1000(FONT.widthOf(g));
  return (w * size) / 1000;
}
function wrap(s, size, maxW) {
  const lines = [];
  let cur = "";
  for (const ch of String(s)) {
    if (ch === "\n") { lines.push(cur); cur = ""; continue; }
    if (textWidth(cur + ch, size) > maxW) { lines.push(cur); cur = ch; }
    else cur += ch;
  }
  lines.push(cur);
  return lines;
}

/* ---------------- 文档 ---------------- */
class PdfDoc {
  constructor() { this.pages = []; this.newPage(); }
  newPage() { this.pages.push([]); this.y = A4.h - MARGIN; }
  get ops() { return this.pages[this.pages.length - 1]; }
  fill(r, g, b) { this.ops.push(`${r} ${g} ${b} rg`); }
  rect(x, y, w, h, r, g, b) { this.ops.push(`${r} ${g} ${b} rg ${x} ${y} ${w} ${h} re f`); }
  text(x, y, size, str, r, g, b) {
    this.fill(r, g, b);
    this.ops.push(`BT /F1 ${size} Tf 1 0 0 1 ${x.toFixed(1)} ${y.toFixed(1)} Tm [<${hexGids(str)}>] Tj ET`);
  }
  para(str, size, color, opts = {}) {
    const maxW = A4.w - MARGIN * 2 - (opts.indent || 0);
    const lineH = size * 1.55;
    for (const ln of wrap(str, size, maxW)) {
      if (this.y < MARGIN + lineH + 20) this.newPage();
      this.text(MARGIN + (opts.indent || 0), this.y - size, size, ln, color[0], color[1], color[2]);
      this.y -= lineH;
    }
  }
  section(title) {
    if (this.y < MARGIN + 90) this.newPage();
    this.y -= 10;
    this.rect(MARGIN, this.y - 16, 6, 20, 0.42, 0.35, 0.85);
    this.text(MARGIN + 14, this.y - 12, 14, title, 0.13, 0.14, 0.30);
    this.y -= 32;
  }
  bullet(str, color) {
    const maxW = A4.w - MARGIN * 2 - 18;
    const lines = wrap(str, 10.5, maxW);
    const c = color || [0.25, 0.27, 0.35];
    lines.forEach((ln, i) => {
      if (this.y < MARGIN + 34) this.newPage();
      if (i === 0) this.text(MARGIN + 4, this.y - 10.5, 10.5, "·", 0.42, 0.35, 0.85);
      this.text(MARGIN + 18, this.y - 10.5, 10.5, ln, c[0], c[1], c[2]);
      this.y -= 17;
    });
    this.y -= 4;
  }
  build() {
    if (!FONT) throw new Error("PDF 字体未就绪");
    const nPages = this.pages.length;
    // 对象：1 catalog, 2 pages, 3 type0, 4 cidfont2, 5 descriptor, 6 W数组流, 7 FontFile2流, 8 info; 页面从 9 起
    const kids = [];
    for (let i = 0; i < nPages; i++) kids.push(`${9 + i * 2} 0 R`);
    // 收集使用过的 gid -> 宽度
    const used = new Set();
    this.pages.forEach((ops) => ops.forEach((o) => {
      const m = o.match(/\[<([0-9A-F]+)>\]/);
      if (m) for (let i = 0; i < m[1].length; i += 4) used.add(parseInt(m[1].slice(i, i + 4), 16));
    }));
    const wPairs = [];
    [...used].sort((a, b) => a - b).forEach((g) => wPairs.push(`${g} [${toW1000(FONT.widthOf(g))}]`));
    const fontBuf = zlib.deflateSync(FONT.raw, { level: 9 });
    const objs = [];
    objs[1] = `<< /Type /Catalog /Pages 2 0 R >>`;
    objs[2] = `<< /Type /Pages /Kids [${kids.join(" ")}] /Count ${nPages} >>`;
    objs[3] = `<< /Type /Font /Subtype /Type0 /BaseFont /DroidSansFallback /Encoding /Identity-H /DescendantFonts [4 0 R] >>`;
    objs[4] = `<< /Type /Font /Subtype /CIDFontType2 /BaseFont /DroidSansFallback /CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> /DW 1000 /W [${wPairs.join(" ")}] /FontDescriptor 5 0 R /CIDToGIDMap /Identity >>`;
    objs[5] = `<< /Type /FontDescriptor /FontName /DroidSansFallback /Flags 4 /FontBBox [0 -300 2048 2000] /ItalicAngle 0 /Ascent 1900 /Descent -500 /CapHeight 1500 /StemV 80 /FontFile2 7 0 R >>`;
    objs[6] = { stream: "unused" }; // 占位保持编号（W 并入 obj4）
    objs[7] = { fontStream: fontBuf };
    objs[8] = `<< /Title <${hexGids("星策·职业体检报告")}> /Producer <${hexGids("星策 XingCe")}> >>`;
    this.pages.forEach((ops, i) => {
      const pid = 9 + i * 2, cid = pid + 1;
      objs[pid] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${A4.w} ${A4.h}] /Resources << /Font << /F1 3 0 R >> >> /Contents ${cid} 0 R >>`;
      objs[cid] = { stream: ops.join("\n") };
    });
    // 序列化（全程 Buffer，避免二进制被隐式 UTF-8 转换破坏）
    const parts = [];
    let pos = 0;
    const push = (x) => { const b = Buffer.isBuffer(x) ? x : Buffer.from(x, "binary"); parts.push(b); pos += b.length; };
    push("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");
    const offsets = [0];
    for (let i = 1; i < objs.length; i++) {
      if (!objs[i]) continue;
      offsets[i] = pos;
      const o = objs[i];
      if (o.fontStream !== undefined) {
        push(`${i} 0 obj\n<< /Length ${o.fontStream.length} /Length1 ${FONT.raw.length} /Filter /FlateDecode >>\nstream\n`);
        push(o.fontStream);
        push("\nendstream\nendobj\n");
        continue;
      }
      if (typeof o === "object" && o.stream !== undefined) {
        if (o.stream === "unused") { push(`${i} 0 obj\nnull\nendobj\n`); continue; }
        push(`${i} 0 obj\n<< /Length ${Buffer.byteLength(o.stream, "utf8")} >>\nstream\n${o.stream}\nendstream\nendobj\n`);
      } else {
        push(`${i} 0 obj\n${o}\nendobj\n`);
      }
    }
    const xrefPos = pos;
    const maxObj = objs.length - 1;
    let xref = `xref\n0 ${maxObj + 1}\n0000000000 65535 f \n`;
    for (let i = 1; i <= maxObj; i++) {
      xref += offsets[i] !== undefined ? String(offsets[i]).padStart(10, "0") + " 00000 n \n" : "0000000000 65535 f \n";
    }
    push(xref);
    push(`trailer\n<< /Size ${maxObj + 1} /Root 1 0 R /Info 8 0 R >>\nstartxref\n${xrefPos}\n%%EOF`);
    return Buffer.concat(parts);
  }
}

/* ============ 报告 -> PDF ============ */
const INK = [0.15, 0.16, 0.24], SUB = [0.38, 0.40, 0.50], PURPLE = [0.42, 0.35, 0.90], GOLD = [0.72, 0.55, 0.16];

function fmtItem(x) {
  if (typeof x === "string") return x;
  return (x && (x.desc || x.描述 || x.text || x.content)) || JSON.stringify(x);
}

function buildReportPDF(rep) {
  if (!FONT) throw new Error("PDF 字体文件缺失（assets/fonts/DroidSansFallback.ttf）");
  const d = new PdfDoc();
  const li = fmtItem;
  const roleName = (rep.role && (rep.role.name || rep.roleName)) || "职场人";
  const score = typeof rep.healthScore === "number" ? rep.healthScore : (rep.score ?? 0);
  const levelText = rep.levelText || rep.healthLevel || (score >= 70 ? "良好" : score >= 50 ? "需关注" : "需行动");
  const eco = rep.ecosystem || "";
  const sw = rep.sw || rep.swot || {};
  const routes = rep.routes || {};
  const actions = rep.actions || rep.actionPlan || [];
  const now = new Date();
  const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;

  d.rect(0, A4.h - 120, A4.w, 120, 0.10, 0.09, 0.25);
  d.text(MARGIN, A4.h - 58, 24, "星策 · 职业体检报告", 1, 1, 1);
  d.text(MARGIN, A4.h - 86, 11, `未来职场就业神器  |  ${roleName}  |  ${dateStr}`, 0.78, 0.82, 0.95);
  d.y = A4.h - 150;

  d.para(levelText, 15, PURPLE);
  d.para(`职业健康度评分：${score} / 100`, 12, INK);
  if (rep.summary) d.para(rep.summary, 10.5, SUB);
  d.y -= 6;

  if (eco) { d.section("生态位判断"); d.para(eco, 10.5, [0.25, 0.27, 0.35]); d.y -= 4; }

  const swotDef = [["strength", "优势 Strengths"], ["weakness", "劣势 Weaknesses"], ["opportunity", "机会 Opportunities"], ["threat", "威胁 Threats"]];
  let hasSwot = false;
  swotDef.forEach(([k]) => { if (sw[k] && sw[k].length) hasSwot = true; });
  if (hasSwot) {
    d.section("SWOT 分析");
    swotDef.forEach(([k, name]) => {
      const arr = sw[k] || [];
      if (!arr.length) return;
      if (d.y < MARGIN + 60) d.newPage();
      d.text(MARGIN, d.y - 11, 11.5, name, GOLD[0], GOLD[1], GOLD[2]);
      d.y -= 20;
      arr.forEach((it) => d.bullet(li(it)));
    });
  }

  const routeDef = [["stay", "留任发展"], ["leave", "离职跳槽"], ["transform", "转型 / 重启"]];
  if (routes && Object.keys(routes).length) {
    d.section("三条路径 · 成功概率");
    routeDef.forEach(([k, name]) => {
      const rt = routes[k];
      if (!rt) return;
      if (d.y < MARGIN + 70) d.newPage();
      const prob = rt.probability ?? 0;
      d.text(MARGIN, d.y - 12, 12, name, INK[0], INK[1], INK[2]);
      d.text(A4.w - MARGIN - 60, d.y - 12, 13, `${prob}%`, prob >= 60 ? 0.1 : prob >= 40 ? 0.6 : 0.85, prob >= 60 ? 0.65 : 0.5, prob >= 60 ? 0.3 : 0.2);
      const barW = (A4.w - MARGIN * 2) * Math.min(100, Math.max(0, prob)) / 100;
      d.rect(MARGIN, d.y - 22, A4.w - MARGIN * 2, 5, 0.90, 0.90, 0.94);
      d.rect(MARGIN, d.y - 22, barW, 5, 0.42, 0.35, 0.90);
      d.y -= 34;
      if (rt.advice) d.para(rt.advice, 10.5, [0.25, 0.27, 0.35]);
      (rt.actions || []).forEach((a) => d.bullet(li(a)));
      d.y -= 6;
    });
  }

  if (actions.length) {
    d.section("未来 90 天行动清单");
    actions.forEach((a, i) => d.bullet(`${i + 1}. ${li(a)}`));
  }

  if (d.y < MARGIN + 60) d.newPage();
  d.y -= 8;
  d.para(rep.disclaimer || "本报告由 AI 智能分析生成，仅供参考，不构成任何职业决策的唯一依据。重大决定请结合自身实际情况并咨询专业人士。", 8.5, [0.55, 0.57, 0.65]);

  return d.build();
}

module.exports = { buildReportPDF };
