#!/bin/bash
# 星策 · 未来职场就业神器 —— macOS 双击启动器
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "❌ 未找到 node，请先安装 Node.js"
  read -p "按回车关闭..."
  exit 1
fi
echo "🌟 星策正在启动…"
( sleep 1.5 && open "http://127.0.0.1:8787" ) &
node server.js
